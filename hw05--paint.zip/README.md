### CIS 1200 Homework 5: GUI Programming & Paint

This homework comes with *detailed* instructions. Before doing anything
else, read them thoroughly.

- [Homework Description](http://www.cis.upenn.edu/~cis1200/current/hw/hw05/)
- [FAQ](https://www.seas.upenn.edu/~cis1200/current/hw/hw05/faq/)

Once you are finished, use the "Zip" menu item to create a file called
"hw05-submit(<time>).zip" and upload it here:

- [Homework Submission Site](https://www.cis.upenn.edu/~cis1200/current/submitredirect/)


Codio documentation can be found here:

- [CIS 1200 Codio Documentation](http://www.cis.upenn.edu/~cis1200/current/codio)
